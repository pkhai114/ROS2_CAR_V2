# Kiểm tra robot_station_auto_v2

Baseline: SCR_RB.zip do người dùng gửi. Kiểm tra ngày 2026-08-30.

## Kết quả đã thực hiện

- `python3 -m unittest discover -s robot_navigation_bringup/test -v`: 64 tests, OK.
- `python3 -m compileall -q robot_navigation_bringup robot_docking`: thành công.
- Parse YAML và package.xml: thành công.
- File script/test/guide được CMake tham chiếu: tồn tại.
- So sánh byte với ZIP gốc: 18 file cần giữ nguyên (stations, Nav2 params, navigation launch, manager thủ công cũ, map và toàn bộ localization) không đổi.
- So sánh AST: `follow_line`, `line_geometry`, `align_to_yaw`, `angular_command`, `publish_motion` không đổi thuật toán so với controller gốc.

Kiểm thử workflow bao gồm các đường thành công, timeout từng pha, bỏ kết quả cũ/sai, kiểm tra undock trước khi điều hướng tiếp, và không tự dock chỉ dựa vào Nav2 SUCCEEDED. Kiểm thử adapter gọi trực tiếp phương thức từ mã nguồn thật với message/action giả, bao gồm late acceptance sau cancel, kết quả tức thời, scan/odom stamp cũ, gate pose/yaw/vận tốc/khoảng trước, chống lệnh lặp và watchdog arbiter.

## Chưa xác minh

- Không có ROS 2 Humble trong môi trường tạo gói: chưa chạy colcon build/test, graph DDS hoặc launch thực tế.
- Pytest không được cài trong môi trường này; bộ test được chạy bằng unittest. Hook CMake/ament_pytest cần xác nhận trên máy ROS của người dùng.
- Chưa có kiểm thử với robot thật, mô phỏng động học, vật cản, quãng đường phanh hoặc watchdog ESP32.
- Không xác nhận độ chính xác vật lý chỉ từ kết quả unit test. Các điều kiện sensor/pose là điều kiện phần mềm, không thay thế giám sát và E-stop.

Đọc STATION_AUTO_GUIDE.md và thử từng nhiệm vụ có giám sát trước khi chạy chuyển trạm.
