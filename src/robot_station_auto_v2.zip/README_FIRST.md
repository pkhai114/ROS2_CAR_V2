# robot_station_auto_v2

Bản cập nhật từ SCR_RB.zip cho chuỗi:

- station_1: Nav2 staging 1, kiểm tra, tự dock.
- station_2 khi đang dock trạm 1: tự undock về staging 1, kiểm tra, Nav2 staging 2, tự dock.

ZIP chứa hai package đầy đủ. Sao lưu hai package cũ ra NGOÀI src trước khi thay. Không chạy manager/arbiter/controller cũ song song với launch AUTO.

Hướng dẫn cài đặt, build, khởi động, lệnh thử và xử lý lỗi:

`robot_navigation_bringup/STATION_AUTO_GUIDE.md`

Launch mới:

```bash
ros2 launch robot_docking stations_auto.launch.py
```

Phải chạy Nav2, localization và cảm biến như cấu hình hiện tại. Gói không thay localization/HOME. Đọc các kiểm tra an toàn trong hướng dẫn trước khi phát lệnh: đã kiểm thử logic offline, chưa thử ROS/HW.
